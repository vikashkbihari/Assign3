﻿using System;

namespace Ass3_4
{
    class Program
    {     
        static void Main(string[] args)
        {  int j=0,k=0;
            Console.WriteLine("enter the value ");
            int num =int.Parse(Console.ReadLine());
             Console.Write("{0}",1);
            for(int i=2;i<=num;i++){
                k=0;
                while(k<i){
                        Console.Write("{0}",i);
                     k++;
                }
            }
        }
    }
}
