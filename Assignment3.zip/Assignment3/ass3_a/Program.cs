﻿using System;

namespace ass3_a
{
   public class Math
    {
        int _side1;
        int _side2;
        public Math(int side1,int side2){
         _side1=side1;
         _side2=side2;
        }
        public static int CalculatePerimeter(int _side1,int _side2){
              if(_side1==_side2){ return 4*_side1;}
              else {return 2*(_side1+_side2);}
             
        }
    }    
      public class program
      {
        static void Main(string[] args)
        {    
            Console.WriteLine("Enter the side1 value");
            int s1=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the side2 value");
            int s2=int.Parse(Console.ReadLine());
            Math math=new Math(s1,s2);
            //Console.WriteLine("Hello World!");
           int per= Math.CalculatePerimeter(s1,s2);
           Console.WriteLine("calculated perimeter is {0}",per);
        }
      }
    }
