﻿using System;  
class Program  
{  
    static void Main()  
    {  
        int i;  
        int[] a = new int[30]; 
        Console.Write("Enter the Number: ");  
        String str=Console.ReadLine();
        int n= str.Length,sum=0;
        // read the string value (by default) and convert it in to integer  
       // int n = Convert.ToInt16(Console.ReadLine());   
        //Reading the values one by one  
        for (i = 1; i <= n; i++)  
         {   a[i] =Convert.ToInt32 (str[i-1]);   
             if(a[i]%2==0){
                 sum=sum+a[i]-48;
             }
           
         }  
        //Sorting the values  
        for (i = 1; i <= n; i++)  
        {  
            for (int j = 1; j <= n - 1; j++)  
            {  
                if (a[j] > a[j + 1])  
                {  
                    int temp = a[j];  
                    a[j] = a[j + 1];  
                    a[j + 1] = temp;  
                }  
            }  
        }  
        //Display the Ascending values one by one  
       
        Console.Write("number in non-increasing order are :");  
        for (i = 1; i <= n; i++)  
        {   

            Console.Write(a[i]-48);
        }
      if(sum>15)
          Console.Write("{0}" ,true); 
        else 
          Console.Write("{0}" ,false); 
    }  
}