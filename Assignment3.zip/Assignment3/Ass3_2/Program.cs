﻿using System;

namespace Ass3_2
{
    class Program
    {
        static void Main(string[] args)
        {   
             Console.WriteLine("Enter the string (Input 1) ");
               string str=Console.ReadLine();
            Console.WriteLine("Enter the Number (INput2) ");
               int num=int.Parse(Console.ReadLine());
            //Console.WriteLine("length is {0}" ,str.Length);
            int len= str.Length;
            // Substring having last n characters.
             string sub = str.Substring(len-num);
            // Console.WriteLine("Substring: {0}", sub);
             string st;
             while(num>0)
             {
                st=str+sub;
                num= num-1;
                 str=st;
             }
             Console.WriteLine("Output : {0}",str);
        }
    }
}
