﻿using System;

namespace Ass3_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Number ");
            int num=int.Parse(Console.ReadLine());
            if(num>=20 && num<=30)
            { 
                if(num%2==0)
                Console.WriteLine(" Tom ");
                else
                Console.WriteLine(" Jerry ");
            }
            else
              Console.WriteLine("No is not as expected ");
        }
    }
}
