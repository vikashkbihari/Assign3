﻿using System;

namespace Ass3
{
    class Program
    { 
        public static void Main(string[] args)
        {   long num=0,rev=0,temp,rem,sum=0;
            Console.WriteLine("Enter the Number");
            num=Convert.ToInt64(Console.ReadLine());
            temp=num;
            while(num>0)
                {
                  rem=num%10;
                       if(rem%2==0)
                      {
                      sum=sum+rem;
                      }
                  rev=rev*10+rem;
                  num=num/10;
                }
            if(rev==temp)    
             {   if(sum>25)
                     {Console.WriteLine("NUmber is a palindrom and sumof even number is greater than 25");}
                 else
                     {Console.WriteLine("NUmber is a palindrom and sumof even number is Less than 25");}
             }
             else
             Console.WriteLine("Number is not a Palindrome");
        
            }
    }
}
